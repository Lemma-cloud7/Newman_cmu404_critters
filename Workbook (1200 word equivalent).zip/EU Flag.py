from turtle import *
    
setup(600,400)                      #EU flag dimensions are 3:2 
bgcolor("blue")                     #Color of the flag
penup()
goto(50,133.33)                     #This is offset of the star constellation radius
pendown()

#Create a function to draw a 5-point star
def makeStar():
    heading_before_star = heading() #Local variable to save the current heading in order to get the star always point upward
    setheading(0)                   #Reset the heading
    for k in range(5):              #Loop to draw the star
        forward(22.22)              #Outer radius of the star, 1/18th of the height of the flag
        right(144)                  #Turning angle
    setheading(heading_before_star) #Save heading to the local variable
    
setheading(-15)         #Aligning the stars 
for i in range(12):     #Loop to draw 12 stars constellation of the flag
    color("yellow")     #Color of the star
    begin_fill()        
    makeStar()          #Function makeStar that draw the 5-point star
    end_fill()
    right(30)           #Every star of the constellation is 30 degree from the center
    penup()
    forward(66.665)     #Radius of the star constellation
    pendown()
