from turtle import *


#Draw the royal blue background of the flag
color("royalblue")
begin_fill()
forward(150)
right(90)
forward(90)
right(90)
forward(150)
right(90)
forward(90)
right(90)
end_fill()

#Repositioning and draw the first diagonal
color("white")
penup()
forward(5)
pendown()
begin_fill()
right(30)
forward(180)
right(90)
forward(10)
right(90)
forward(190)
right(90)
forward(10)
end_fill()

#Repositioning on bottom side of the flag

right(150)
forward(100)
left(90)

#Draw the second diagonal

color("white")
penup()
forward(5)
pendown()
begin_fill()
left(30)
forward(180)
left(90)
forward(10)
left(90)
forward(190)
left(90)
forward(10)
end_fill()
