from turtle import *

#Drow the outline of the flag
color ("black")
for i in range (2): #Loop to draw the outline
    forward(150)
    right(90)
    forward(100)
    right(90)
#Repositioning to draw the circle
penup()
forward(45)
right(90)
forward(50)
pendown()
#Drawing the circle
color("red")
begin_fill()
circle(30)
end_fill()
