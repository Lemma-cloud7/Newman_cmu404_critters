from turtle import *

#Drawing the red rectangle
color("red")
begin_fill()
for i in range (2):
    forward(200)
    right(90)
    forward(150)
    right(90)
end_fill()

penup()
forward(100)
right(90)
forward(75)
right(180)
forward(50)
right(90)
pendown()


color("yellow")     #Color of the star
right(72)
begin_fill()
forward(100)
right(144)
forward(100)
right(144)
forward(100)
right(144)
forward(100)
right(144)
forward(100)
end_fill()

hideturtle()
#begin_fill()        
#for k in range(5):                  #Loop to draw the star
#        forward(50)                 #Outer radius of the star, 1/18th of the height of the flag
#        right(144)                  #Turning angle
#end_fill()

