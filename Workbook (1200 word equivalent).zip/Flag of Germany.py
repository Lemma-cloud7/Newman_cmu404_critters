from turtle import *

#Create a function to draw a strip
def makeStrip(): 
    begin_fill()
    for i in range (2): #Loop to drow a strip
        forward(150)
        right(90)
        forward(30)
        right(90)
    end_fill()
#Reposition to the left bottom side of the strip
    penup()
    right(90)
    forward(30)
    pendown()
    left(90)

#Draw the black strip
color("black") 
makeStrip()
#Draw the red strip
color("red")
makeStrip()
#Draw the yellow strip
color("yellow")
makeStrip()


