from turtle import *

#Create a function to draw a strip
def makeStrip(): 
    begin_fill()
    for i in range (2): #Loop to drow a strip
        forward(50)
        right(90)
        forward(100)
        right(90)
    end_fill()

#Reposition to the upper right side of the strip
    penup()
    forward(50)
    pendown()

#Draw the blue strip
color("blue") 
makeStrip()
#Draw the white strip
color("white")
makeStrip()
#Draw the red strip
color("red")
makeStrip()


