from critter import *
class Bird(Critter):
    def __init__(self):
        super(Bird, self).__init__()
        self.steps = 3                  #number of the criter will make in every direction
        self.movement = 0               #used to alternate directions of movement
        self.direct = 0                 #used to "remember" the direction of critter's movement 

    def eat(self):
        return False

    def fight(self, opponent):
        if (opponent == "%"):       #check if the opponent is Ant and use ROAR as attack 
            return ATTACK_ROAR
        else:
            return ATTACK_POUNCE

    def get_color(self):
        return "blue"

    def get_move(self):
        while self.steps>1: #using loop to make 3 steps in every direction
            if self.movement % 4 == 0:  #using modulo operator to evaluate direction of the movement
                self.direct = DIRECTION_NORTH #set direction of movement to NORTH 
            elif self.movement % 4 == 1 :
                self.direct = DIRECTION_EAST #set direction of movement to EAST
            elif self.movement % 4== 2 :
                self.direct = DIRECTION_SOUTH #set direction of movement to SOUTH
            elif self.movement %4  == 3 :
                self.direct = DIRECTION_WEST #set direction of movement to WEST
            self.steps-=1 #update the steps value within the loop
            return self.direct #return the value of the direction from the loop
        self.steps=3 #reset the steps count for the loop 
        self.movement+=1 #change the direction of movement 
        return self.direct #return the value of the direction outside the loop used for the symbol which the critter gets in every direction

    def __str__(self):
        if self.direct==0: #check if te direction is NORTH to draw "^" symbol
            return "^"
        if self.direct==1: #check if te direction is SOUTH to draw "V" symbol
            return "V"
        if self.direct==2: #check if te direction is EAST to draw ">" symbol
            return ">"
        if self.direct==3: #check if te direction is WEST to draw "<" symbol
            return "<"
