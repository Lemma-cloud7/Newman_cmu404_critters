from critter import *
import random

class Wildcat(Critter):
    def __init__(self):
        super(Wildcat, self).__init__() 
        self.eaten = 0 #used to check if the critter will eat   
        self.move=0 #attribute set to zero and it can be used to alternate directions
        self.walk_south=bool(random.getrandbits(1)) #using getrandombits function as boolan to movement of the wildcat
        self.direct = 0 #used ot "remember" the critter direction of movement
        self.hippo='0123456789' #set used to determinate if the opponent is hippo
        self.bird='^>V<' #set used to determinate if the opponent is bird
        self.vulture=self.bird  #set used to determinate if the opponent is volture  
       
    def eat(self): 
        if self.eaten ==0: #determine if the critter has eaten
            return True
        return False
        
    def fight(self, opponent):
        if opponent == "%": #determine if the critter is Ant and attack with ROAR
            return ATTACK_ROAR
        elif opponent in set(self.bird): #used set to determine if the critter is bird and attack with SCRATCH
            return ATTACK_SCRATCH
        elif opponent in set(self.hippo): #used set to determine if the critter is hippo and attack with SCRATCH
            return ATTACK_SCRATCH
        elif opponent in set(self.vulture): #used set to determine if the critter is vulture and attack with SCRATCH 
            return ATTACK_SCRATCH
        else:
            return ATTACK_POUNCE
        
    def get_color(self): #set the color of the critter to brown
        return "brown"

    def get_move(self):
        self.move+=1 #using the expression to update value in-place by one for every move of the critter
        if self.walk_south == True: #check if the critter is created with "True" value so it can alternate between SOUTH-WEST directions
            if self.move %2 ==0: #Using modulo operator to set direction to WEST every second move
                return DIRECTION_WEST
            return DIRECTION_SOUTH
        elif self.walk_south == False: #check if the critter is createrd with "False" value so it can alternate between SOUTH-WEST directions
            if self.move %2 == 0:   #using modulo operator to set direction to WEST every second move
                return DIRECTION_WEST
            return DIRECTION_NORTH

        
    def __str__(self): #set the symbol of the critter to W
            return "W"
