from critter import *
import random

class Ant(Critter):
    def __init__(self,walk_south):
        super(Ant, self).__init__()
        self.walk_south=bool(random.getrandbits(1)) #using getrandombits function as boolan to movement of ants
                                                    #it is generated randomly for every ant created with the constructor 
        self.move = int(0)                          #attribute set to zero and it can be used to alternate directions 

    def eat(self):
        return True

    def fight(self, opponent):
        return ATTACK_SCRATCH                       

    def get_color(self):
        return "red"

    def get_move(self):
        self.move+=1                                #using the expression to update value in-place by one for every move of the critter
        if self.walk_south == True:                 #check if the critter is created with "True" value so it can alternate between south-east directions
            if self.move %2 == 0:                   #Using modulo operator to set direction to EAST every second move 
                return DIRECTION_EAST
            else:
                return DIRECTION_SOUTH
        elif self.walk_south == False:              #check if the critter is createrd with "False" value so it can alternate between north-east directions
            if self.move %2 == 0:                   #using modulo operator to set direction to EAST every second move
                return DIRECTION_EAST
            else:
                return DIRECTION_NORTH
        
    def __str__(self):
        return "%"
