from critter import *
from random import randint

class Hippo(Critter):
    def __init__(self,hunger):
        super(Hippo, self).__init__()
        self.steps = 5  #number of steps used in the loop that hippo will make 
        self.direct = 0 #used ot "remember" the critter direction of movement
        self.movement = randint(0,3) #using radint function to randomly change direction of movement 
        self.hunger = hunger #attribute with random value for the maximum number of times the critter will eat

    def eat(self):
        if self.hunger > 0: #check if critter still can eat
            self.hunger-=1  #decrease the number of times the critter will eat
            return True
        else:
             return False
    
    def fight(self, opponent):
        if self.hunger > 0: #check if the critter is hunger
            return ATTACK_SCRATCH #if the critter is hunger will attack with SCRATCH
        else:
            return ATTACK_POUNCE #if the critter is no longer hunger will attack with POUNCE
        
    def get_color(self): #using bool function to evaluate if the critter has eaten
        if bool(self.eaten)== True: 
            return "grey"
        if bool(self.eaten) == False: 
            return "white"

    def get_move(self):
        while self.steps > 1: #usig loop to make 5 steps in every direction
            if self.movement %4 == 0:   #using modulo operator to evaluate direction of movement
                self.direct = DIRECTION_NORTH #set the direction of movement to NORTH
            elif self.movement %4 == 1:
                self.direct = DIRECTION_EAST #set the direction of movement to EAST
            elif self.movement %4 == 2:
                self.direct = DIRECTION_SOUTH #set the direction of movement to SOUTH
            elif self.movement  %4 == 3:
                self.direct = DIRECTION_WEST #set the direction of movement to WES
            else:
                break
            self.steps-=1 #decrease number of steps within the loop
            return self.direct #return the direction of movement within the loop
        self.steps=5 #reset the steps count for the loop
        self.movement = randint(0,3) #using radint funcion to randomly change direction of movement
        return self.direct #return the direction of the movement outside the loop

    def __str__(self):
        return str(self.hunger) #display number of pieces of food the critter still wants to eat as symbol
       
